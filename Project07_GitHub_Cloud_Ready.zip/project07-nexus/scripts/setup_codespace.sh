#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m venv backend/.venv
backend/.venv/bin/python -m pip install -r backend/requirements.txt
cd frontend
npm ci
npm run build
