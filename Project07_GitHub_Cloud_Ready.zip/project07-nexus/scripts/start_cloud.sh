#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../backend"
exec .venv/bin/python -m uvicorn cloud:app --host 0.0.0.0 --port "${PORT:-8000}"
